﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //var s1 = new Student
            //{
            //    Id = 1,
            //    Name = "Elnur",
            //    Surname = "Meherremli"
            //};
            //var s2 = new Student
            //{
            //    Id = 2,
            //    Name = "Elnur2",
            //    Surname = "Meherremli2"
            //};
            //var s3 = new Student
            //{
            //    Id = 3,
            //    Name = "Elnur3",
            //    Surname = "Meherremli"
            //};

            //var students = new List<Student> { s1, s2, s3 };
            //var studentsJson = JsonConvert.SerializeObject(students);

            //File.WriteAllText(@"C:\Users\EshginK\Desktop\students.json", studentsJson);

            var readedJson = File.ReadAllText(@"C:\Users\EshginK\Desktop\students.json");
            var deserializedStudents = JsonConvert.DeserializeObject<List<Student>>(readedJson);

            foreach (var student in deserializedStudents.Skip(1))
            {
                Console.WriteLine(student.Id + " - " + student.Name + " - " + student.Surname);
            }
        }
    }

    internal class Student
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Surname { get; set; }
    }
}
